<?php
 // created: 2016-03-17 23:21:33
$dictionary['Opportunity']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>
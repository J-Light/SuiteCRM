<?php
 // created: 2016-07-13 08:18:52
$dictionary['Account']['fields']['organisation_address_pcode_c']['inline_edit']='1';
$dictionary['Account']['fields']['organisation_address_pcode_c']['labelValue']='Organisation Address Postcode';

 ?>
<?php
 // created: 2016-07-13 02:36:47
$dictionary['Note']['fields']['flag_due_date_c']['inline_edit']='1';
$dictionary['Note']['fields']['flag_due_date_c']['labelValue']='Flag Due Date';

 ?>
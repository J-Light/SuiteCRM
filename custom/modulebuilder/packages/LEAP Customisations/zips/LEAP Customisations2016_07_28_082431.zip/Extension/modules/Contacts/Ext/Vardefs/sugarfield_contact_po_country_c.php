<?php
 // created: 2016-07-13 09:13:13
$dictionary['Contact']['fields']['contact_po_country_c']['inline_edit']='1';
$dictionary['Contact']['fields']['contact_po_country_c']['labelValue']='Contact PO Country';

 ?>
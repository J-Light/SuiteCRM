<?php
 // created: 2016-07-14 04:37:32
$dictionary['CM2_Leap_Leads']['fields']['name']['required']=false;
$dictionary['CM2_Leap_Leads']['fields']['name']['inline_edit']=true;
$dictionary['CM2_Leap_Leads']['fields']['name']['duplicate_merge']='disabled';
$dictionary['CM2_Leap_Leads']['fields']['name']['duplicate_merge_dom_value']='0';
$dictionary['CM2_Leap_Leads']['fields']['name']['merge_filter']='disabled';
$dictionary['CM2_Leap_Leads']['fields']['name']['unified_search']=false;

 ?>
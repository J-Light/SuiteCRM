<?php
 // created: 2016-07-13 08:49:02
$dictionary['CM1_Department']['fields']['dept_po_country_c']['inline_edit']='1';
$dictionary['CM1_Department']['fields']['dept_po_country_c']['labelValue']='Dept PO Country';

 ?>
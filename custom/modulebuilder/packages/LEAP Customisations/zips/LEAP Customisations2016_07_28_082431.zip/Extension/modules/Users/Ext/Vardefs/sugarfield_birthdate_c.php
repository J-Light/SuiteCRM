<?php
 // created: 2016-03-30 03:40:15
$dictionary['User']['fields']['birthdate_c']['inline_edit']='1';
$dictionary['User']['fields']['birthdate_c']['labelValue']='Birthdate';

 ?>
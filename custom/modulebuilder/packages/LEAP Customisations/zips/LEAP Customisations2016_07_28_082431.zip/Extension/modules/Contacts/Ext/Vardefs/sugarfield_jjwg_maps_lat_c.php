<?php
 // created: 2016-03-17 23:21:11
$dictionary['Contact']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>
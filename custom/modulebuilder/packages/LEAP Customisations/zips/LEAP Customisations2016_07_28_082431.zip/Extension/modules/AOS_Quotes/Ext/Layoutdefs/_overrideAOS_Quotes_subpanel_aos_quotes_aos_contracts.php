<?php
//auto-generated file DO NOT EDIT
$layout_defs['AOS_Quotes']['subpanel_setup']['aos_quotes_aos_contracts']['override_subpanel_name'] = 'AOS_Quotes_subpanel_aos_quotes_aos_contracts';
?>
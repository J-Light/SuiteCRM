<?php
 // created: 2016-07-13 08:47:12
$dictionary['CM1_Department']['fields']['dept_po_state_c']['inline_edit']='1';
$dictionary['CM1_Department']['fields']['dept_po_state_c']['labelValue']='Dept PO State';

 ?>
<?php
 // created: 2016-03-17 23:21:40
$dictionary['Project']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>
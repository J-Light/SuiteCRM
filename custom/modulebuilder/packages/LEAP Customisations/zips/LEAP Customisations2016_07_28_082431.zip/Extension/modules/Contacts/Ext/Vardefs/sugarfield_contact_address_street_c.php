<?php
 // created: 2016-07-13 09:03:40
$dictionary['Contact']['fields']['contact_address_street_c']['inline_edit']='1';
$dictionary['Contact']['fields']['contact_address_street_c']['labelValue']='Contact Address Street';

 ?>
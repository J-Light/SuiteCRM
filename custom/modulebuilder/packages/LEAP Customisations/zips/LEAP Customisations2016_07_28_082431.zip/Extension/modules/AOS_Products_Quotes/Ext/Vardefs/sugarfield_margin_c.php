<?php
 // created: 2016-04-08 01:10:14
$dictionary['AOS_Products_Quotes']['fields']['margin_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['margin_c']['labelValue']='Margin';

 ?>
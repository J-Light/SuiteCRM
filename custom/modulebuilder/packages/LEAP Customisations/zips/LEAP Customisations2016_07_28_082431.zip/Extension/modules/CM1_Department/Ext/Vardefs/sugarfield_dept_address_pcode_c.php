<?php
 // created: 2016-07-13 08:40:42
$dictionary['CM1_Department']['fields']['dept_address_pcode_c']['inline_edit']='1';
$dictionary['CM1_Department']['fields']['dept_address_pcode_c']['labelValue']='Dept Address Postcode';

 ?>
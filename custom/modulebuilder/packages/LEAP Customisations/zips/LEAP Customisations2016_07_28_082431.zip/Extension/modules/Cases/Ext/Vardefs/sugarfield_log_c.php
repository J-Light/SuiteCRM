<?php
 // created: 2016-07-28 06:01:20
$dictionary['Case']['fields']['log_c']['inline_edit']='1';
$dictionary['Case']['fields']['log_c']['labelValue']='Log';

 ?>
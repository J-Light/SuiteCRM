<?php
 // created: 2016-07-13 09:18:17
$dictionary['Contact']['fields']['contact_home_country_c']['inline_edit']='1';
$dictionary['Contact']['fields']['contact_home_country_c']['labelValue']='Contact Home Country';

 ?>
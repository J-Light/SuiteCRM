<?php
 // created: 2016-05-04 05:16:11
$dictionary['AOS_Products_Quotes']['fields']['account_number_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['account_number_c']['labelValue']='Account Number';

 ?>
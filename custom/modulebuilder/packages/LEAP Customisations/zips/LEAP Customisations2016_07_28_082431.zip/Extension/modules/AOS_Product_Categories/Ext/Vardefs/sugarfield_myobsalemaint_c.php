<?php
 // created: 2016-05-26 05:05:05
$dictionary['AOS_Product_Categories']['fields']['myobsalemaint_c']['inline_edit']='1';
$dictionary['AOS_Product_Categories']['fields']['myobsalemaint_c']['labelValue']='MYOBSaleMaint';

 ?>
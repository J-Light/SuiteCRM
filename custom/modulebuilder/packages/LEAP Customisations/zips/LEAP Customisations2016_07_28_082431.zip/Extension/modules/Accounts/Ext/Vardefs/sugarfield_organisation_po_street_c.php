<?php
 // created: 2016-07-13 08:22:27
$dictionary['Account']['fields']['organisation_po_street_c']['inline_edit']='1';
$dictionary['Account']['fields']['organisation_po_street_c']['labelValue']='Organisation PO Street';

 ?>
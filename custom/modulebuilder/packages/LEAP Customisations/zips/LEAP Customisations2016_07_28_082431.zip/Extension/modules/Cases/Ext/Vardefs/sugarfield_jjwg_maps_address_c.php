<?php
 // created: 2016-03-17 23:21:08
$dictionary['Case']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 ?>
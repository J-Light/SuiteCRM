<?php
 // created: 2016-05-31 02:42:05
$dictionary['AOS_Quotes']['fields']['tax_code_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['tax_code_c']['labelValue']='Tax Code';

 ?>
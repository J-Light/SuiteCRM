<?php
// created: 2016-07-12 01:07:07
$dictionary["Account"]["fields"]["accounts_cm1_department_1"] = array (
  'name' => 'accounts_cm1_department_1',
  'type' => 'link',
  'relationship' => 'accounts_cm1_department_1',
  'source' => 'non-db',
  'module' => 'CM1_Department',
  'bean_name' => 'CM1_Department',
  'side' => 'right',
  'vname' => 'LBL_ACCOUNTS_CM1_DEPARTMENT_1_FROM_CM1_DEPARTMENT_TITLE',
);

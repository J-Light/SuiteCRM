<?php
 // created: 2016-05-18 00:42:03
$dictionary['AOS_Products_Quotes']['fields']['supplier_margin_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['supplier_margin_c']['labelValue']='Supplier Margin';

 ?>
<?php
 // created: 2016-05-18 00:40:53
$dictionary['AOS_Products_Quotes']['fields']['supplier_amount_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['supplier_amount_c']['labelValue']='Supplier Amount';

 ?>
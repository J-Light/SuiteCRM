<?php
 // created: 2016-04-07 06:08:41
$dictionary['AOS_Invoices']['fields']['purchase_order_date_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['purchase_order_date_c']['labelValue']='Purchase Order Date';

 ?>
<?php
 // created: 2016-04-26 05:20:36
$dictionary['AOS_Product_Categories']['fields']['myob_last_name_c']['inline_edit']='1';
$dictionary['AOS_Product_Categories']['fields']['myob_last_name_c']['labelValue']='MYOB Last Name';

 ?>
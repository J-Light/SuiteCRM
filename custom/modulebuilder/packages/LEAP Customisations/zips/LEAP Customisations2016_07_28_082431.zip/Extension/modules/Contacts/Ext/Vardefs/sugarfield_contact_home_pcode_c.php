<?php
 // created: 2016-07-13 09:17:20
$dictionary['Contact']['fields']['contact_home_pcode_c']['inline_edit']='1';
$dictionary['Contact']['fields']['contact_home_pcode_c']['labelValue']='Contact Home Postcode';

 ?>
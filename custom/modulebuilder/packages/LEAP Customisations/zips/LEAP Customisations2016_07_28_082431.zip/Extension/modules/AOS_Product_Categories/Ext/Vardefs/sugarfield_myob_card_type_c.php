<?php
 // created: 2016-04-26 05:24:40
$dictionary['AOS_Product_Categories']['fields']['myob_card_type_c']['inline_edit']='1';
$dictionary['AOS_Product_Categories']['fields']['myob_card_type_c']['labelValue']='MYOB Card Type';

 ?>
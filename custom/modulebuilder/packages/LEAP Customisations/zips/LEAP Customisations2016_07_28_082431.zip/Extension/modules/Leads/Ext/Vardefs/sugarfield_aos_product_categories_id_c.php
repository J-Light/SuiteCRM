<?php
 // created: 2016-07-14 02:35:01
$dictionary['Lead']['fields']['aos_product_categories_id_c']['inline_edit']=1;

 ?>
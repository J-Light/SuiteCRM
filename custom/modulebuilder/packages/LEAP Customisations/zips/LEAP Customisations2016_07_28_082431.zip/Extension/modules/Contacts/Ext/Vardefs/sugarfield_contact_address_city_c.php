<?php
 // created: 2016-07-13 09:04:48
$dictionary['Contact']['fields']['contact_address_city_c']['inline_edit']='1';
$dictionary['Contact']['fields']['contact_address_city_c']['labelValue']='Contact Address City';

 ?>
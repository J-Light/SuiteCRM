<?php
 // created: 2016-04-26 05:17:10
$dictionary['AOS_Product_Categories']['fields']['myob_card_name_c']['inline_edit']='1';
$dictionary['AOS_Product_Categories']['fields']['myob_card_name_c']['labelValue']='MYOB Card Name';

 ?>
<?php
 // created: 2016-05-26 05:07:21
$dictionary['AOS_Product_Categories']['fields']['myobsaleconsulting_c']['inline_edit']='1';
$dictionary['AOS_Product_Categories']['fields']['myobsaleconsulting_c']['labelValue']='MYOBSaleConsulting';

 ?>
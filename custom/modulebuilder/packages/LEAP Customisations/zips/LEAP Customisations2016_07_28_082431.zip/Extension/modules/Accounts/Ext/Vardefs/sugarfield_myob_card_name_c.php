<?php
 // created: 2016-07-27 05:40:26
$dictionary['Account']['fields']['myob_card_name_c']['inline_edit']='1';
$dictionary['Account']['fields']['myob_card_name_c']['labelValue']='MYOB Card Name';

 ?>
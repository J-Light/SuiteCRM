<?php
 // created: 2016-03-17 23:21:25
$dictionary['Meeting']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>
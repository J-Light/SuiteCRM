<?php
 // created: 2016-07-13 08:23:18
$dictionary['Account']['fields']['organisation_po_city_c']['inline_edit']='1';
$dictionary['Account']['fields']['organisation_po_city_c']['labelValue']='Organisation PO City';

 ?>
<?php
 // created: 2016-04-06 08:12:26
$dictionary['AOS_Invoices']['fields']['myob_sale_id_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['myob_sale_id_c']['labelValue']='MYOB Sale ID';

 ?>
<?php
 // created: 2016-05-06 00:35:18
$dictionary['AOS_Invoices']['fields']['customer_purchase_order_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['customer_purchase_order_c']['labelValue']='Customer Purchase Order';

 ?>
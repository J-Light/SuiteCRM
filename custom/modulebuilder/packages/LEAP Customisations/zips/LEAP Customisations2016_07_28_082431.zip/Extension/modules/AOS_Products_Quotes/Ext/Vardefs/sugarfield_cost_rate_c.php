<?php
 // created: 2016-04-08 01:09:13
$dictionary['AOS_Products_Quotes']['fields']['cost_rate_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['cost_rate_c']['labelValue']='Cost Rate';

 ?>
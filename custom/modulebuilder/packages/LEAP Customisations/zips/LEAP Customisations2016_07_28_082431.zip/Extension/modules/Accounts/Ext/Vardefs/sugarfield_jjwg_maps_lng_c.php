<?php
 // created: 2016-03-17 23:20:53
$dictionary['Account']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>
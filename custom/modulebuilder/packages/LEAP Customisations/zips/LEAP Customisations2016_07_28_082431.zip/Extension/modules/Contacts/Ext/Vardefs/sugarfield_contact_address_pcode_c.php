<?php
 // created: 2016-07-13 09:07:45
$dictionary['Contact']['fields']['contact_address_pcode_c']['inline_edit']='1';
$dictionary['Contact']['fields']['contact_address_pcode_c']['labelValue']='Contact Address Postcode';

 ?>
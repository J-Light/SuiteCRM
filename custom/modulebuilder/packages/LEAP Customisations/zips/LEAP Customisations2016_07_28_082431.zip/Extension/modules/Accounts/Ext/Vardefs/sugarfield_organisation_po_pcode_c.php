<?php
 // created: 2016-07-13 08:24:58
$dictionary['Account']['fields']['organisation_po_pcode_c']['inline_edit']='1';
$dictionary['Account']['fields']['organisation_po_pcode_c']['labelValue']='Organisation PO Postcode';

 ?>
<?php
 // created: 2016-04-08 01:00:39
$dictionary['AOS_Products_Quotes']['fields']['price_currency_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['price_currency_c']['labelValue']='Price Currency';

 ?>
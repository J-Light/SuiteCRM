<?php
 // created: 2016-07-13 08:15:01
$dictionary['Account']['fields']['organisation_address_street_c']['inline_edit']='1';
$dictionary['Account']['fields']['organisation_address_street_c']['labelValue']='Organisation Address Street';

 ?>
<?php
 // created: 2016-04-06 08:17:09
$dictionary['AOS_Invoices']['fields']['myob_sale_paid_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['myob_sale_paid_c']['labelValue']='MYOB Sale Paid';

 ?>
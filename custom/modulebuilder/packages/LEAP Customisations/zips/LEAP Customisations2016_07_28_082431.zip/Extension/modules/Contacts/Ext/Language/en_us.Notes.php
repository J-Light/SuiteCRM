<?php
$mod_strings['LBL_NOTES_SUBPANEL_TITLE'] = 'Notes';
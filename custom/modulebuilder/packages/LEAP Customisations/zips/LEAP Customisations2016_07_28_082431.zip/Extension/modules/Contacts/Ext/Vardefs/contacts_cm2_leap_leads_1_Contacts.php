<?php
// created: 2016-07-14 04:32:38
$dictionary["Contact"]["fields"]["contacts_cm2_leap_leads_1"] = array (
  'name' => 'contacts_cm2_leap_leads_1',
  'type' => 'link',
  'relationship' => 'contacts_cm2_leap_leads_1',
  'source' => 'non-db',
  'module' => 'CM2_Leap_Leads',
  'bean_name' => 'CM2_Leap_Leads',
  'side' => 'right',
  'vname' => 'LBL_CONTACTS_CM2_LEAP_LEADS_1_FROM_CM2_LEAP_LEADS_TITLE',
);

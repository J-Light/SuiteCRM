<?php
 // created: 2016-03-17 23:20:57
$dictionary['Account']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 ?>
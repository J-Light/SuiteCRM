<?php
 // created: 2016-05-26 05:11:33
$dictionary['AOS_Product_Categories']['fields']['myobpurchasetraining_c']['inline_edit']='1';
$dictionary['AOS_Product_Categories']['fields']['myobpurchasetraining_c']['labelValue']='MYOBPurchaseTraining';

 ?>
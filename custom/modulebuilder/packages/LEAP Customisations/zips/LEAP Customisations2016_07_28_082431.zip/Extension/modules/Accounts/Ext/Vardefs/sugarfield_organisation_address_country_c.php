<?php
 // created: 2016-07-13 08:21:37
$dictionary['Account']['fields']['organisation_address_country_c']['inline_edit']='1';
$dictionary['Account']['fields']['organisation_address_country_c']['labelValue']='Organisation Address Country';

 ?>
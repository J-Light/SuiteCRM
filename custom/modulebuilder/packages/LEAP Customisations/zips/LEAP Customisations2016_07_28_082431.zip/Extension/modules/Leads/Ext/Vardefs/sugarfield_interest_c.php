<?php
 // created: 2016-07-14 03:24:15
$dictionary['Lead']['fields']['interest_c']['inline_edit']='1';
$dictionary['Lead']['fields']['interest_c']['labelValue']='Interest';

 ?>
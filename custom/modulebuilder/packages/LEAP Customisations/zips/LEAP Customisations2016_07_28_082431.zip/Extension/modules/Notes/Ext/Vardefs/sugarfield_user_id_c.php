<?php
 // created: 2016-07-13 02:58:21
$dictionary['Note']['fields']['user_id_c']['inline_edit']=1;

 ?>
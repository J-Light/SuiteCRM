<?php
 // created: 2016-07-13 08:17:48
$dictionary['Account']['fields']['organisation_address_state_c']['inline_edit']='1';
$dictionary['Account']['fields']['organisation_address_state_c']['labelValue']='Organisation Address State';

 ?>
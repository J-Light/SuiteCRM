<?php
 // created: 2016-07-28 06:17:53
$dictionary['Case']['fields']['date_fixed_c']['inline_edit']='1';
$dictionary['Case']['fields']['date_fixed_c']['labelValue']='Date Fixed';

 ?>
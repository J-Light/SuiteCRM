<?php
 // created: 2016-03-17 23:21:28
$dictionary['Meeting']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 ?>
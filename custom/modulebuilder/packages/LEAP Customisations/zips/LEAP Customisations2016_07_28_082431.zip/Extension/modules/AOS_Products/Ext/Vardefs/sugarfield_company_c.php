<?php
 // created: 2016-04-14 08:40:36
$dictionary['AOS_Products']['fields']['company_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['company_c']['labelValue']='Company';

 ?>
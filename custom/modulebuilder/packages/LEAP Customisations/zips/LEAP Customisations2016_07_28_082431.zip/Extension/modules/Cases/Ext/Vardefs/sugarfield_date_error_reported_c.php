<?php
 // created: 2016-07-28 06:11:48
$dictionary['Case']['fields']['date_error_reported_c']['inline_edit']='1';
$dictionary['Case']['fields']['date_error_reported_c']['labelValue']='Date Error Reported';

 ?>
<?php
 // created: 2016-05-26 05:06:38
$dictionary['AOS_Product_Categories']['fields']['myobsaletraining_c']['inline_edit']='1';
$dictionary['AOS_Product_Categories']['fields']['myobsaletraining_c']['labelValue']='MYOBSaleTraining';

 ?>
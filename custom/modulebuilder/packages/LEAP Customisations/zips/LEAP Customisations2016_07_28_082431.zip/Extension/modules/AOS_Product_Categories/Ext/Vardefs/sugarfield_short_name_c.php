<?php
 // created: 2016-03-30 06:32:21
$dictionary['AOS_Product_Categories']['fields']['short_name_c']['inline_edit']='1';
$dictionary['AOS_Product_Categories']['fields']['short_name_c']['labelValue']='Short Name';

 ?>
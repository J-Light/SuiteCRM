<?php
// created: 2016-07-12 02:03:34
$dictionary["CM1_Department"]["fields"]["cm1_department_contacts_1"] = array (
  'name' => 'cm1_department_contacts_1',
  'type' => 'link',
  'relationship' => 'cm1_department_contacts_1',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'side' => 'right',
  'vname' => 'LBL_CM1_DEPARTMENT_CONTACTS_1_FROM_CONTACTS_TITLE',
);

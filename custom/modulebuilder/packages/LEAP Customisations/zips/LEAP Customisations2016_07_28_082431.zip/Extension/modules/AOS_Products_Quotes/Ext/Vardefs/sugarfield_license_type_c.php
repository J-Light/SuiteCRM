<?php
 // created: 2016-06-07 01:59:21
$dictionary['AOS_Products_Quotes']['fields']['license_type_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['license_type_c']['labelValue']='License Type';

 ?>
<?php
 // created: 2016-05-04 08:06:48
$dictionary['AOS_Invoices']['fields']['tax_code_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['tax_code_c']['labelValue']='Tax Code';

 ?>
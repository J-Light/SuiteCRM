<?php
 // created: 2016-07-14 03:22:56
$dictionary['Lead']['fields']['role_c']['inline_edit']='1';
$dictionary['Lead']['fields']['role_c']['labelValue']='Role';

 ?>
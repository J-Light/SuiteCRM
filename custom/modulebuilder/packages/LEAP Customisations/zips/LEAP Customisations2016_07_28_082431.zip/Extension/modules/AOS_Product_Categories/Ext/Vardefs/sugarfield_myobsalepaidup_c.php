<?php
 // created: 2016-05-26 05:04:14
$dictionary['AOS_Product_Categories']['fields']['myobsalepaidup_c']['inline_edit']='1';
$dictionary['AOS_Product_Categories']['fields']['myobsalepaidup_c']['labelValue']='MYOBSalePaidup';

 ?>
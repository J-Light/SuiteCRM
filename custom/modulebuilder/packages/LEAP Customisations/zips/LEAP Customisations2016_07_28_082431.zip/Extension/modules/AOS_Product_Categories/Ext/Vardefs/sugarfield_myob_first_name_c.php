<?php
 // created: 2016-04-26 05:19:44
$dictionary['AOS_Product_Categories']['fields']['myob_first_name_c']['inline_edit']='1';
$dictionary['AOS_Product_Categories']['fields']['myob_first_name_c']['labelValue']='MYOB First Name';

 ?>
<?php
 // created: 2016-06-02 02:35:31
$dictionary['AOS_Products_Quotes']['fields']['cost_discount_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['cost_discount_c']['labelValue']='Cost Discount';

 ?>
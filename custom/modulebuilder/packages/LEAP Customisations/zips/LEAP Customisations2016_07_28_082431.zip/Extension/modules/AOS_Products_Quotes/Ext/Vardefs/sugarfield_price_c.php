<?php
 // created: 2016-04-08 00:59:00
$dictionary['AOS_Products_Quotes']['fields']['price_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['price_c']['labelValue']='Price';

 ?>
<?php
 // created: 2016-07-13 08:39:57
$dictionary['CM1_Department']['fields']['dept_address_state_c']['inline_edit']='1';
$dictionary['CM1_Department']['fields']['dept_address_state_c']['labelValue']='Dept Address State';

 ?>
<?php
 // created: 2016-07-13 09:14:59
$dictionary['Contact']['fields']['contact_home_city_c']['inline_edit']='1';
$dictionary['Contact']['fields']['contact_home_city_c']['labelValue']='Contact Home City';

 ?>
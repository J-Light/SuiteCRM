<?php
 // created: 2016-05-04 07:21:03
$dictionary['AOS_Products_Quotes']['fields']['job_number_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['job_number_c']['labelValue']='Job Number';

 ?>
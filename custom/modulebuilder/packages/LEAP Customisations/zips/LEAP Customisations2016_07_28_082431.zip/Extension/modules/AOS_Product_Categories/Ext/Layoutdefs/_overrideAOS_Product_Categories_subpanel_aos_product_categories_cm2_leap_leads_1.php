<?php
//auto-generated file DO NOT EDIT
$layout_defs['AOS_Product_Categories']['subpanel_setup']['aos_product_categories_cm2_leap_leads_1']['override_subpanel_name'] = 'AOS_Product_Categories_subpanel_aos_product_categories_cm2_leap_leads_1';
?>
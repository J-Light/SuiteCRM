<?php
 // created: 2016-03-18 01:12:14
$dictionary['AOS_Products']['fields']['cost_2_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['cost_2_c']['labelValue']='Cost';

 ?>
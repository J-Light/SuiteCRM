<?php
 // created: 2016-03-17 23:21:24
$dictionary['Meeting']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>
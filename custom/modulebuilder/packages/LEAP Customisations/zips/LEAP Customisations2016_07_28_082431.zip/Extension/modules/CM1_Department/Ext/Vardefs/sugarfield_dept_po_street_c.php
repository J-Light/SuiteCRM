<?php
 // created: 2016-07-13 08:42:32
$dictionary['CM1_Department']['fields']['dept_po_street_c']['inline_edit']='1';
$dictionary['CM1_Department']['fields']['dept_po_street_c']['labelValue']='Dept PO Street';

 ?>
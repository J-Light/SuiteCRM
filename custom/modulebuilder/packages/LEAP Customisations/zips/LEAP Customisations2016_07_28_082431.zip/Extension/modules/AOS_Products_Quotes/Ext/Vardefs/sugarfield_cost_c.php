<?php
 // created: 2016-04-08 01:05:25
$dictionary['AOS_Products_Quotes']['fields']['cost_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['cost_c']['labelValue']='Cost';

 ?>
<?php
 // created: 2016-07-13 09:16:23
$dictionary['Contact']['fields']['contact_home_state_c']['inline_edit']='1';
$dictionary['Contact']['fields']['contact_home_state_c']['labelValue']='Contact Home State';

 ?>
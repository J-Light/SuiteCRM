<?php
 // created: 2016-03-17 23:21:30
$dictionary['Meeting']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 ?>
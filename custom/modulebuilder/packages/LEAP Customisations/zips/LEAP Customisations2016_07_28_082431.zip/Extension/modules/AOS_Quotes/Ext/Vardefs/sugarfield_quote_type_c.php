<?php
 // created: 2016-04-08 02:26:49
$dictionary['AOS_Quotes']['fields']['quote_type_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['quote_type_c']['labelValue']='Quote Type';

 ?>
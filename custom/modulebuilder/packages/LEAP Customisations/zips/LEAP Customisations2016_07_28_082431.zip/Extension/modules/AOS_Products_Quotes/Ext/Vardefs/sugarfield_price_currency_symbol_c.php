<?php
 // created: 2016-04-08 01:02:41
$dictionary['AOS_Products_Quotes']['fields']['price_currency_symbol_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['price_currency_symbol_c']['labelValue']='Price Currency Symbol';

 ?>
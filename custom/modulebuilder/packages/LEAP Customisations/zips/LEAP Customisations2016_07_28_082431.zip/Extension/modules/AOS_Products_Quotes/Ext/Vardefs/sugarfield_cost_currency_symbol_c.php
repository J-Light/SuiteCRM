<?php
 // created: 2016-04-08 01:08:16
$dictionary['AOS_Products_Quotes']['fields']['cost_currency_symbol_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['cost_currency_symbol_c']['labelValue']='Cost Currency Symbol';

 ?>
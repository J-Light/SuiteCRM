<?php
 // created: 2016-04-08 01:04:05
$dictionary['AOS_Products_Quotes']['fields']['price_rate_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['price_rate_c']['labelValue']='Price Rate';

 ?>
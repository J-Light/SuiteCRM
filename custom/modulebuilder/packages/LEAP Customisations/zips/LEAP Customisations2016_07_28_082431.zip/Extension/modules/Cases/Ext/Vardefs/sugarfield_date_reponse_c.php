<?php
 // created: 2016-07-28 06:15:02
$dictionary['Case']['fields']['date_reponse_c']['inline_edit']='1';
$dictionary['Case']['fields']['date_reponse_c']['labelValue']='Date Reponse';

 ?>
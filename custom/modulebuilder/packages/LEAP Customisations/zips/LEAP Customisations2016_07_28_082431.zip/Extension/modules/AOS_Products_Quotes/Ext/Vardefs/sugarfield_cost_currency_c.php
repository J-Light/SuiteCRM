<?php
 // created: 2016-04-08 01:07:21
$dictionary['AOS_Products_Quotes']['fields']['cost_currency_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['cost_currency_c']['labelValue']='Cost Currency';

 ?>
<?php
 // created: 2016-07-14 02:35:01
$dictionary['Lead']['fields']['lead_type_c']['inline_edit']='1';
$dictionary['Lead']['fields']['lead_type_c']['labelValue']='Lead Type';

 ?>
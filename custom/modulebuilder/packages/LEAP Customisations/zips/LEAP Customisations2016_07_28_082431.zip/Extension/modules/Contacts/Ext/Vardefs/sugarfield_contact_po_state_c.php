<?php
 // created: 2016-07-13 09:11:29
$dictionary['Contact']['fields']['contact_po_state_c']['inline_edit']='1';
$dictionary['Contact']['fields']['contact_po_state_c']['labelValue']='Contact PO State';

 ?>
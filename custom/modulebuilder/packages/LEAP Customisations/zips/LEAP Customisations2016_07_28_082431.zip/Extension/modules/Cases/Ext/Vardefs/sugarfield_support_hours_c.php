<?php
 // created: 2016-07-28 06:23:21
$dictionary['Case']['fields']['support_hours_c']['inline_edit']='1';
$dictionary['Case']['fields']['support_hours_c']['labelValue']='Support Hours';

 ?>
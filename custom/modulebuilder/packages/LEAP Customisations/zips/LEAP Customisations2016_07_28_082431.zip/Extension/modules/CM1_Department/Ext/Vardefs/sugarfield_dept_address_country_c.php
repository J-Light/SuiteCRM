<?php
 // created: 2016-07-13 08:41:27
$dictionary['CM1_Department']['fields']['dept_address_country_c']['inline_edit']='1';
$dictionary['CM1_Department']['fields']['dept_address_country_c']['labelValue']='Dept Address Country';

 ?>
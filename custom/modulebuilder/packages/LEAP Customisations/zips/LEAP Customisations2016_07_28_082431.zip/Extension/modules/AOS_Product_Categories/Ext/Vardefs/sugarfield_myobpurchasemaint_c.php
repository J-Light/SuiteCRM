<?php
 // created: 2016-05-26 05:09:53
$dictionary['AOS_Product_Categories']['fields']['myobpurchasemaint_c']['inline_edit']='1';
$dictionary['AOS_Product_Categories']['fields']['myobpurchasemaint_c']['labelValue']='MYOBPurchaseMaint';

 ?>
<?php
 // created: 2016-07-13 09:12:26
$dictionary['Contact']['fields']['contact_po_pcode_c']['inline_edit']='1';
$dictionary['Contact']['fields']['contact_po_pcode_c']['labelValue']='Contact PO Postcode';

 ?>
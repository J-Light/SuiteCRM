<?php
 // created: 2016-05-04 08:09:26
$dictionary['AOS_Invoices']['fields']['myob_card_name_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['myob_card_name_c']['labelValue']='MYOB Card Name';

 ?>
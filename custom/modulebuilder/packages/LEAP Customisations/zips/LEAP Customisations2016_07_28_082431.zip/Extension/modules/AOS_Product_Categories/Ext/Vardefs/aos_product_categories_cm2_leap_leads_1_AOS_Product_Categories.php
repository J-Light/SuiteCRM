<?php
// created: 2016-07-14 04:35:03
$dictionary["AOS_Product_Categories"]["fields"]["aos_product_categories_cm2_leap_leads_1"] = array (
  'name' => 'aos_product_categories_cm2_leap_leads_1',
  'type' => 'link',
  'relationship' => 'aos_product_categories_cm2_leap_leads_1',
  'source' => 'non-db',
  'module' => 'CM2_Leap_Leads',
  'bean_name' => 'CM2_Leap_Leads',
  'side' => 'right',
  'vname' => 'LBL_AOS_PRODUCT_CATEGORIES_CM2_LEAP_LEADS_1_FROM_CM2_LEAP_LEADS_TITLE',
);

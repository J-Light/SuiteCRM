<?php
 // created: 2016-04-08 00:33:45
$dictionary['AOS_Products']['fields']['license_type_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['license_type_c']['labelValue']='License Type';

 ?>
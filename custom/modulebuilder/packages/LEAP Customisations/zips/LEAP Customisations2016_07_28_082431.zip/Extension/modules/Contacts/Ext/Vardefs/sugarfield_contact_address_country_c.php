<?php
 // created: 2016-07-13 09:08:39
$dictionary['Contact']['fields']['contact_address_country_c']['inline_edit']='1';
$dictionary['Contact']['fields']['contact_address_country_c']['labelValue']='Contact Address Country';

 ?>
<?php
 // created: 2016-04-06 08:18:02
$dictionary['AOS_Invoices']['fields']['myob_sale_date_paid_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['myob_sale_date_paid_c']['labelValue']='MYOB Sale Date Paid';

 ?>
<?php
 // created: 2016-07-13 04:30:52
$dictionary['Note']['fields']['priority_c']['inline_edit']='1';
$dictionary['Note']['fields']['priority_c']['labelValue']='Priority';

 ?>
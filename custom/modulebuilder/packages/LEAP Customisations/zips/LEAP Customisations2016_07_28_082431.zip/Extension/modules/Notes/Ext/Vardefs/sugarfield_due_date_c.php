<?php
 // created: 2016-07-12 08:11:20
$dictionary['Note']['fields']['due_date_c']['inline_edit']='1';
$dictionary['Note']['fields']['due_date_c']['labelValue']='Due Date';

 ?>
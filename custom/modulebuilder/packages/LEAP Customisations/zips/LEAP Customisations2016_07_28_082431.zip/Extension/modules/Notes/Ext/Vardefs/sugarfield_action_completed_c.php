<?php
 // created: 2016-07-13 02:44:49
$dictionary['Note']['fields']['action_completed_c']['inline_edit']='1';
$dictionary['Note']['fields']['action_completed_c']['labelValue']='Action Completed';

 ?>
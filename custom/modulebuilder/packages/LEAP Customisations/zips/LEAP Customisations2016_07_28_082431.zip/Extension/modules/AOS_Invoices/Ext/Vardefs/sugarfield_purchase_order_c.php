<?php
 // created: 2016-03-29 07:13:40
$dictionary['AOS_Invoices']['fields']['purchase_order_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['purchase_order_c']['labelValue']='Purchase Order';

 ?>
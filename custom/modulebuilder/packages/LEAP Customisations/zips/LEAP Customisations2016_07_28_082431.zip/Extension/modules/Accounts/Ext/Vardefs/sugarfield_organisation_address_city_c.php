<?php
 // created: 2016-07-13 08:16:34
$dictionary['Account']['fields']['organisation_address_city_c']['inline_edit']='1';
$dictionary['Account']['fields']['organisation_address_city_c']['labelValue']='Organisation Address City';

 ?>
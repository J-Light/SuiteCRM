<?php
 // created: 2016-07-13 02:58:21
$dictionary['Note']['fields']['actionee_c']['inline_edit']='1';
$dictionary['Note']['fields']['actionee_c']['labelValue']='Actionee';

 ?>
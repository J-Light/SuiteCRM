<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/accounts_cm1_department_1MetaData.php');

?>
<?php

include('scripts/config.php');
include('scripts/functions.php');
require_once('scripts/database.php');
	
class after_save {
    function after_save(&$bean, $event, $arguments){
		global $current_user;
		$db = new Database();
		
		$product_id = $bean->product_id;
		$product_quote_id = $bean->id;
		
		$product_quote = new AOS_Products_Quotes($product_quote_id);
		
		if($product_id) {
			$product = new AOS_Products();
			$product->retrieve($product_id);
			$currencies = $db->get_currencies_by_symbol();
			$currencies_symbol = $db->get_currencies_symbol_by_id();
			$currencies_rate = $db->get_currencies_rate();
			
			$cost_price = self::number_unformat($product->cost_2_c);
			$cost_currency_symbol = $product->cost_currency_c;
			$cost_currency_id = $currencies[$cost_currency_symbol];
			$cost_rate = $currencies_rate[$cost_currency_id];
			
			$price = self::number_unformat($bean->product_unit_price);
			$price_currency_symbol = $currencies_symbol[$bean->currency_id];
			$price_currency_id = $bean->currency_id;
			$price_rate = $currencies_rate[$price_currency_id];
			
			// Converting currencies
			$converted_cost = ($cost_rate * $cost_price) / $price_rate;
			
			// Compute for Margin
			$margin = (($price - $converted_cost) / $price) * 100;
			
			$data = array(
				array(
					'id_c' => $product_quote_id,
					'price_c' => $price, 
					'price_currency_symbol_c' => $price_currency_symbol, 
					'price_currency_c' => $price_currency_id, 
					'price_rate_c' => $price_rate, 
					'cost_c' => $cost_price, 
					'cost_currency_symbol_c' => $cost_currency_symbol, 
					'cost_currency_c' => $cost_currency_id, 
					'cost_rate_c' => $cost_rate, 
					'margin_c' => $margin
				),
			);
			
			$sql = generate_insert_script('aos_products_quotes_cstm', $data);
			$GLOBALS['db']->query($sql);
		}
	}
	
	function number_unformat($number, $force_number = true, $dec_point = '.', $thousands_sep = ',') {
		if ($force_number) {
			$number = preg_replace('/^[^\d]+/', '', $number);
		} else if (preg_match('/^[^\d]+/', $number)) {
			return false;
		}
		$type = (strpos($number, $dec_point) === false) ? 'int' : 'float';
		$number = str_replace(array($dec_point, $thousands_sep), array('.', ''), $number);
		settype($number, $type);
		return $number;
	}
}
?>
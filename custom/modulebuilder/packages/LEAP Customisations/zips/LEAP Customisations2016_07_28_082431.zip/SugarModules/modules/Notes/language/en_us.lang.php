<?php 
 // created: 2016-07-28 08:23:49
$mod_strings['LBL_DUE_DATE'] = 'Due Date';
$mod_strings['LBL_NOTES_NAME'] = 'Name';
$mod_strings['LBL_LIST_CONTACT_NOTES'] = 'Contact';
$mod_strings['LBL_LIST_ACCOUNT_NOTES'] = 'Account';
$mod_strings['LBL_NOTES_PARENT_TYPE'] = 'Parent Type';
$mod_strings['LBL_FLAG_DUE_DATE'] = 'Flag Due Date';
$mod_strings['LBL_ACTION_COMPLETED'] = 'Action Completed';
$mod_strings['LBL_ACTIONEE_USER_ID'] = 'Actionee (related User ID)';
$mod_strings['LBL_ACTIONEE'] = 'Actionee';
$mod_strings['LBL_NOTES_FLAG_DUE_DATE'] = 'Flag Due Date';
$mod_strings['LBL_NOTES_ACTION_COMPLETED'] = 'Action Completed';
$mod_strings['LBL_PRIORITY'] = 'Priority';
$mod_strings['LBL_LEADS'] = 'Leads Original';

?>

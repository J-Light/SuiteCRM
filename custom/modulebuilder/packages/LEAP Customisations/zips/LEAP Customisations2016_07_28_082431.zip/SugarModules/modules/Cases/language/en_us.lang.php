<?php 
 // created: 2016-07-28 08:23:31
$mod_strings['LBL_LOG'] = 'Log';
$mod_strings['LBL_DATE_ERROR_REPORTED'] = 'Date Error Reported';
$mod_strings['LBL_SUPPORT_NUMBER'] = 'Support Number';
$mod_strings['LBL_DATE_REPONSE'] = 'Date Reponse';
$mod_strings['LBL_DATE_FIXED'] = 'Date Fixed';
$mod_strings['LBL_SUPPORT_HOURS'] = 'Support Hours';

?>

<?php 
 // created: 2016-07-28 08:23:12
$mod_strings['LBL_PRICE'] = 'Price';
$mod_strings['LBL_PRICE_CURRENCY'] = 'Price Currency';
$mod_strings['LBL_PRICE_CURRENCY_SYMBOL'] = 'Price Currency Symbol';
$mod_strings['LBL_PRICE_RATE'] = 'Price Rate';
$mod_strings['LBL_COST'] = 'Cost';
$mod_strings['LBL_COST_CURRENCY'] = 'Cost Currency';
$mod_strings['LBL_COST_CURRENCY_SYMBOL'] = 'Cost Currency Symbol';
$mod_strings['LBL_COST_RATE'] = 'Cost Rate';
$mod_strings['LBL_MARGIN'] = 'Margin';
$mod_strings['LBL_ACCOUNT_NUMBER'] = 'Account Number';
$mod_strings['LBL_JOB_NUMBER'] = 'Job Number';
$mod_strings['LBL_SUPPLIER_AMOUNT'] = 'Supplier Amount';
$mod_strings['LBL_SUPPLIER_MARGIN'] = 'Supplier Margin';
$mod_strings['LBL_COST_DISCOUNT'] = 'Cost Discount';
$mod_strings['LBL_LICENSE_TYPE'] = 'License Type';

?>

<?php 
 // created: 2016-07-28 08:23:30
$mod_strings['LBL_LEADS'] = 'Leads Original';
$mod_strings['LBL_CAMPAIGN_LEAD_SUBPANEL_TITLE'] = 'Leads Original';
$mod_strings['LBL_LOG_ENTRIES_LEAD_TITLE'] = 'Leads Original Created';

?>

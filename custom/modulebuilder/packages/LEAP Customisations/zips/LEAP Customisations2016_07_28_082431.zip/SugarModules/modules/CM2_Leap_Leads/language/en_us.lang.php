<?php 
 // created: 2016-07-28 08:23:29
$mod_strings['LBL_NAME'] = 'Name';

?>

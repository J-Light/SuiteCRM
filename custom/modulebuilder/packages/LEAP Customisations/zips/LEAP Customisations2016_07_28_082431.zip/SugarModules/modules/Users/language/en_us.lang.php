<?php 
 // created: 2016-07-28 08:23:59
$mod_strings['LBL_BIRTHDATE'] = 'Birthdate';

?>

<?php
	$hook_array['after_save'][] = Array(1, 'after_save', 'custom/modules/AOS_Products_Quotes/after_save.php', 'after_save', 'after_save');
?>
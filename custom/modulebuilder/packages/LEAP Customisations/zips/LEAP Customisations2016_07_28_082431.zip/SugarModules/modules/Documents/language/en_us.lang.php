<?php 
 // created: 2016-07-28 08:23:43
$mod_strings['LBL_LEADS'] = 'Leads Original';

?>

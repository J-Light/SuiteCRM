<?php 
 // created: 2016-07-28 08:24:05
$mod_strings['LBL_LEADS'] = 'Leads Original';

?>

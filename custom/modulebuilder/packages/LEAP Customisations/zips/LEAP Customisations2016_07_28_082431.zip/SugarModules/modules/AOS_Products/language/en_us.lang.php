<?php 
 // created: 2016-07-28 08:23:11
$mod_strings['LBL_COST_2'] = 'Cost';
$mod_strings['LBL_COST_CURRENCY'] = 'Cost Currency';
$mod_strings['LBL_TYPE'] = 'Commercial';
$mod_strings['LBL_LICENSE_TYPE'] = 'License Type';
$mod_strings['LBL_COMPANY'] = 'Company';

?>

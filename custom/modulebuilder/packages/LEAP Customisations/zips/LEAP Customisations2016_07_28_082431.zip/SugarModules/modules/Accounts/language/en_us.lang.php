<?php 
 // created: 2016-07-28 08:23:14
$mod_strings['LBL_BILLING_ADDRESS_COUNTRY'] = 'Country';
$mod_strings['LBL_ACCOUNTS_CM1_DEPARTMENT_1_FROM_CM1_DEPARTMENT_TITLE'] = 'Departments';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Address';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'Organisation Address';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'Organisation Address';
$mod_strings['LBL_BILLING_ADDRESS'] = 'Organisation Address:';
$mod_strings['LBL_SHIPPING_ADDRESS'] = 'Organisation PO Box:';
$mod_strings['LBL_ORGANISATION_ADDRESS_STREET'] = 'Street';
$mod_strings['LBL_ORGANISATION_ADDRESS_CITY'] = 'City';
$mod_strings['LBL_ORGANISATION_ADDRESS_STATE'] = 'State';
$mod_strings['LBL_ORGANISATION_ADDRESS_PCODE'] = 'Postcode';
$mod_strings['LBL_ORGANISATION_ADDRESS_COUNTRY'] = 'Country';
$mod_strings['LBL_ORGANISATION_PO_STREET'] = 'treet';
$mod_strings['LBL_ORGANISATION_PO_CITY'] = 'City';
$mod_strings['LBL_ORGANISATION_PO_STATE'] = 'State';
$mod_strings['LBL_ORGANISATION_PO_PCODE'] = 'Postcode';
$mod_strings['LBL_ORGANISATION_PO_COUNTRY'] = 'Country';
$mod_strings['LBL_EDITVIEW_PANEL4'] = 'Organisation PO Box';
$mod_strings['LBL_DETAILVIEW_PANEL2'] = 'Organisation PO Box';
$mod_strings['LBL_LEADS'] = 'Leads Original';
$mod_strings['LBL_LEADS_SUBPANEL_TITLE'] = 'Leads Original';
$mod_strings['LBL_MYOB_CARD_NAME'] = 'MYOB Card Name';

?>

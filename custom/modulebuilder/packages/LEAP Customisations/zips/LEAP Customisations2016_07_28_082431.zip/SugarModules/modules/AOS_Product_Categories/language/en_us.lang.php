<?php 
 // created: 2016-07-28 08:23:02
$mod_strings['LBL_SHORT_NAME'] = 'Short Name';
$mod_strings['LBL_MYOB_CARD_NAME'] = 'MYOB Card Name';
$mod_strings['LBL_MYOB_FIRST_NAME'] = 'MYOB First Name';
$mod_strings['LBL_MYOB_LAST_NAME'] = 'MYOB Last Name';
$mod_strings['LBL_MYOB_CARD_TYPE'] = 'MYOB Card Type';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'MYOB Details';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'MYOB Details';
$mod_strings['LBL_MYOBSALEPAIDUP'] = 'MYOBSalePaidup';
$mod_strings['LBL_MYOBSALEMAINT'] = 'MYOBSaleMaint';
$mod_strings['LBL_MYOBSALELEASE'] = 'MYOBSaleLease';
$mod_strings['LBL_MYOBSALETRAINING'] = 'MYOBSaleTraining';
$mod_strings['LBL_MYOBSALECONSULTING'] = 'MYOBSaleConsulting';
$mod_strings['LBL_MYOBSALEMISC'] = 'MYOBSaleMisc';
$mod_strings['LBL_MYOBPURCHASEPAIDUP'] = 'MYOBPurchasePaidup';
$mod_strings['LBL_MYOBPURCHASEMAINT'] = 'MYOBPurchaseMaint';
$mod_strings['LBL_MYOBPURCHASELEASE'] = 'MYOBPurchaseLease';
$mod_strings['LBL_MYOBPURCHASETRAINING'] = 'MYOBPurchaseTraining';
$mod_strings['LBL_MYOBPURCHASECONSULTING'] = 'MYOBPurchaseConsulting';
$mod_strings['LBL_MYOBPURCHASEMISC'] = 'MYOBPurchaseMisc';
$mod_strings['LBL_AOS_PRODUCT_CATEGORIES_CM2_LEAP_LEADS_1_FROM_CM2_LEAP_LEADS_TITLE'] = 'Leads';

?>

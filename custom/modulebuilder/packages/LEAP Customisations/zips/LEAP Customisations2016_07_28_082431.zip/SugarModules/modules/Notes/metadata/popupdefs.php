<?php
$popupMeta = 
array (
  'moduleMain' => 'Notes',
  'varName' => 'Note',
  'orderBy' => 'notes.name',
  'whereClauses' => 
  array (
    'name' => 'notes.name',
  ),
  'searchInputs' => 
  array (
    0 => 'notes_number',
    1 => 'name',
    2 => 'priority',
    3 => 'status',
  ),
);
?>

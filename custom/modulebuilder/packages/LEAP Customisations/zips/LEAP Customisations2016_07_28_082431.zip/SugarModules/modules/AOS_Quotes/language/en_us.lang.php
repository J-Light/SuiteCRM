<?php 
 // created: 2016-07-28 08:23:13
$mod_strings['LBL_QUOTE_TYPE'] = 'Quote Type';
$mod_strings['AOS_Contracts'] = 'Contracts';
$mod_strings['LBL_TAX_CODE'] = 'Tax Code';

?>

<?php 
 // created: 2016-07-28 08:23:01
$mod_strings['LBL_PURCHASE_ORDER'] = 'Purchase Order';
$mod_strings['LBL_MYOB_SALE_ID'] = 'MYOB Sale ID';
$mod_strings['LBL_MYOB_SALE_DATE'] = 'MYOB Sale Date';
$mod_strings['LBL_MYOB_SALE_TOTAL'] = 'MYOB Sale Total';
$mod_strings['LBL_MYOB_SALE_OUTSTANDING'] = 'MYOB Sale Outstanding';
$mod_strings['LBL_MYOB_SALE_PAID'] = 'MYOB Sale Paid';
$mod_strings['LBL_MYOB_SALE_DATE_PAID'] = 'MYOB Sale Date Paid';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'MYOB Details';
$mod_strings['LBL_PURCHASE_ORDER_DATE'] = 'Purchase Order Date';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'MYOB Details';
$mod_strings['LBL_TAX_CODE'] = 'Tax Code';
$mod_strings['LBL_MYOB_CARD_NAME'] = 'MYOB Card Name';
$mod_strings['LBL_CUSTOMER_PURCHASE_ORDER'] = 'Customer Purchase Order';

?>

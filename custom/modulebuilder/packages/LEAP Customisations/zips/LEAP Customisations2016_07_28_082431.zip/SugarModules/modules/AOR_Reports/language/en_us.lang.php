<?php 
 // created: 2016-07-28 08:22:58
$mod_strings['LNK_NEW_RECORD'] = 'Create Report';
$mod_strings['LNK_LIST'] = 'View Reports (Old)';
$mod_strings['LNK_IMPORT_AOR_REPORTS'] = 'Import Reports (Old)';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Reports (Old) List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search Reports (Old)';
$mod_strings['LBL_MODULE_NAME'] = 'Reports (Old)';

?>

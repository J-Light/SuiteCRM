<?php 
 // created: 2016-07-28 08:22:59
$mod_strings['LBL_AOR_REPORT_NAME'] = 'Reports (Old)';

?>

<?php 
 // created: 2016-07-28 08:23:50
$mod_strings['LBL_LEADS'] = 'Leads Original';
$mod_strings['LBL_LEADS_SUBPANEL_TITLE'] = 'Leads Original';
$mod_strings['LBL_LEAD_SOURCE'] = 'Lead Original Source:';

?>

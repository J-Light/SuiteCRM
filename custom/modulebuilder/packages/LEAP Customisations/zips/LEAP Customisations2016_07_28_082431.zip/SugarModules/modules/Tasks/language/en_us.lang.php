<?php 
 // created: 2016-07-28 08:23:58
$mod_strings['LBL_LEADS'] = 'Leads Original';

?>

<?php 
 // created: 2016-07-28 08:23:23
$mod_strings['LNK_NEW_RECORD'] = 'Create Departments';
$mod_strings['LNK_LIST'] = 'View Departments';
$mod_strings['LNK_IMPORT_CM1_DEPARTMENT'] = 'Import Departments';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Departments List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search Departments';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Departments';
$mod_strings['LBL_DEPT_ADDRESS_STREET'] = 'Street';
$mod_strings['LBL_DEPT_ADDRESS_CITY'] = 'City';
$mod_strings['LBL_DEPT_ADDRESS_STATE'] = 'State';
$mod_strings['LBL_DEPT_ADDRESS_PCODE'] = ' Postcode';
$mod_strings['LBL_DEPT_ADDRESS_COUNTRY'] = 'Country';
$mod_strings['LBL_DEPT_PO_STREET'] = 'Street';
$mod_strings['LBL_DEPT_PO_CITY'] = 'City';
$mod_strings['LBL_DEPT_PO_STATE'] = 'State';
$mod_strings['LBL_DEPT_PO_PCODE'] = 'Postcode';
$mod_strings['LBL_DEPT_PO_COUNTRY'] = 'Country';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Department Address';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'Department PO Box';

?>

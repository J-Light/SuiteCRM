<?php 
 // created: 2016-07-28 08:23:34
$mod_strings['LBL_CONTACT_ADDRESS_STREET'] = 'Street';
$mod_strings['LBL_CONTACT_ADDRESS_CITY'] = 'City';
$mod_strings['LBL_CONTACT_ADDRESS_STATE'] = 'State';
$mod_strings['LBL_CONTACT_ADDRESS_PCODE'] = 'Postcode';
$mod_strings['LBL_CONTACT_ADDRESS_COUNTRY'] = 'Country';
$mod_strings['LBL_CONTACT_PO_STREET'] = 'Street';
$mod_strings['LBL_CONTACT_PO_CITY'] = 'City';
$mod_strings['LBL_CONTACT_PO_STATE'] = 'State';
$mod_strings['LBL_CONTACT_PO_PCODE'] = 'Postcode';
$mod_strings['LBL_CONTACT_PO_COUNTRY'] = 'Country';
$mod_strings['LBL_CONTACT_HOME_STREET'] = 'Street';
$mod_strings['LBL_CONTACT_HOME_CITY'] = 'City';
$mod_strings['LBL_CONTACT_HOME_STATE'] = 'State';
$mod_strings['LBL_CONTACT_HOME_PCODE'] = 'Postcode';
$mod_strings['LBL_CONTACT_HOME_COUNTRY'] = 'Country';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Contact Address';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'Contact PO Box';
$mod_strings['LBL_EDITVIEW_PANEL3'] = 'Contact Home Address';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'Contact Address';
$mod_strings['LBL_DETAILVIEW_PANEL2'] = 'Contact PO Box';
$mod_strings['LBL_DETAILVIEW_PANEL3'] = 'Contact Home Address';
$mod_strings['LBL_LEADS'] = 'Leads Original';
$mod_strings['LBL_LEADS_SUBPANEL_TITLE'] = 'Leads Original';
$mod_strings['LBL_LEAD_SOURCE'] = 'Lead Original Source:';
$mod_strings['LBL_CONTACTS_CM2_LEAP_LEADS_1_FROM_CM2_LEAP_LEADS_TITLE'] = 'Leads';

?>

<?php 
 // created: 2016-07-28 08:23:44
$mod_strings['LBL_LEAD_TYPE_AOS_PRODUCT_CATEGORIES_ID'] = 'Lead Type (related  ID)';
$mod_strings['LBL_LEAD_TYPE'] = 'Lead Type';
$mod_strings['LBL_ROLE'] = 'Role';
$mod_strings['LBL_INTEREST'] = 'Interest';
$mod_strings['LNK_NEW_LEAD'] = 'Create Lead Original';
$mod_strings['LNK_LEAD_LIST'] = 'View Leads Original';
$mod_strings['LNK_IMPORT_VCARD'] = 'Create Lead Original From vCard';
$mod_strings['LNK_IMPORT_LEADS'] = 'Import Leads Original';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Lead Original List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Lead Original Search';
$mod_strings['LBL_REPORTS_TO'] = 'Reports To:';
$mod_strings['LBL_LIST_MY_LEADS'] = 'My Leads Original';
$mod_strings['LBL_LEAD_SOURCE'] = 'Lead Original Source:';
$mod_strings['LBL_LEAD_SOURCE_DESCRIPTION'] = 'Lead Original Source Description:';
$mod_strings['LBL_MODULE_NAME'] = 'Leads Original';

?>

<?php 
 // created: 2016-07-28 08:23:43
$mod_strings['LBL_FP_EVENTS_LEADS_1_FROM_LEADS_TITLE'] = 'Leads Original';

?>
